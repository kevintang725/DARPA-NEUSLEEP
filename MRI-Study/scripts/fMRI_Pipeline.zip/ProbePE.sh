#!/bin/csh
#
set funcdir = $1
set subj = `echo ${funcdir}|awk -F "sub-" '{print $2}'|awk -F "/" '{print $1}'`
set sess = `echo ${funcdir}|awk -F "ses-" '{print $2}'|awk -F "/" '{print $1}'`
cd ${funcdir}/
if (-e ${funcdir}/TopupFiles.txt) then
echo "Already found TopupFiles.txt in ${funcdir}!  Will not continue.  Exiting...."
exit
endif
echo "Checking Phase Encodings for ${subj} for session ${sess}"
foreach image (`ls *.json`)
set imprefix = `echo ${image}|awk -F ".json" '{print $1}'`
set pe = `more ${image}|grep '"'PhaseEncodingDirection'"':`
echo ${imprefix} ${pe}
echo ${imprefix} ${pe} >> TopupFiles_PEs.txt
end
foreach task (`ls *acq-AP*mc.nii.gz|awk -F "task-" '{print $2}'|awk -F "_acq" '{print $1}'`)
echo "Working on ${task} for ${subj}"
set apimage = `ls -1 *${task}*acq-AP*mc.nii.gz`
set apimprefix = `echo ${apimage}|awk -F "_mc.nii.gz" '{print $1}'`
set paimage = `ls -1 *${task}*acq-PA*mc.nii.gz`
set paimprefix = `echo ${paimage}|awk -F "_mc.nii.gz" '{print $1}'`
set apimage_pe = `more TopupFiles_PEs.txt|grep "${apimprefix}"|awk '{print $3}'|cut -c 2,3`
set paimage_pe = `more TopupFiles_PEs.txt|grep "${paimprefix}"|awk '{print $3}'|cut -c 2,3`
if (${apimage_pe} == "j-") then
echo "Subject has a to p phase encoding for ${task}!"
echo "X${apimage}X ${paimage} appa" >> TopupFiles.txt
endif
if (${apimage_pe} != "j-") then
echo "Subject has p to a phase encoding for ${task}"
echo "Will need to manually specify a to p phase encoding functional in TopupFile.txt"
echo "X${apimage}X  paap" >> TopupFiles.txt
endif
end
